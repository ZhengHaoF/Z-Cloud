<?php
$arr = ['key'=>"aaa"];
print_r($arr["key"]);
