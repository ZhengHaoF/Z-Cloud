<?php 
	header("Content-type: text/html; charset=utf-8");
	$MySqlHost = "localhost";
	$MySqlUser = "englishp_ZHF";
	$MySqlPwd = "ZhengHF";
	$MySqlDatabaseName = "englishp_zcloud";
        $host = "http://cloud.zhfblog.ml/"; //网站地址
