var COS = require('./src/cos');
module.exports = COS;